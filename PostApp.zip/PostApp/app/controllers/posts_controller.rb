class PostsController < ApplicationController
	#get route to render tempplate
	def index
		@posts = Post.all
	end

	def new
		@post = Post.new
	end

	def show
		@post = Post.find(params[:id])
	end

	#post route to create post
	def create
	     @post = Post.new(post_params)
	     if @post.save
	     	redirect_to @post
	     else
	     	render 'new'
	     end
	end

    def destroy
		  @post = Post.find(params[:id])
		  @post.destroy
		 
		  redirect_to posts_path
    end

	private
	def post_params
		params.require(:post).permit(:title,:content)
	end


end
